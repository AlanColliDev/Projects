﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DterminaVocaloCons
{
    class Cls_Leras
    {
        private string letra;

        public string Letra
        {
            get
            {
                return letra;
            }

            set
            {
                letra = value;
            }
        }



    }
}
